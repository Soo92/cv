#!/usr/bin/env python
import cv2
import numpy as np
import mahotas
from matplotlib import pyplot as plt
import os
import math
import time
import picamera
import RPi.GPIO as GPIO
import sys
from PIL import Image
import requests
import pytesseract
from StringIO import StringIO
from pytesseract import image_to_string  

GPIO.setmode(GPIO.BCM)
GPIO.setup(17,GPIO.OUT) #11
GPIO.setup(18,GPIO.OUT) #12
GPIO.setup(27,GPIO.OUT) #13 
GPIO.setup(22,GPIO.OUT)	#15 
GPIO.setup(23,GPIO.OUT) #16 
GPIO.setup(24,GPIO.OUT) #18
 
#11pin red 			#12pin green
#13pin yellow			#14pin GND
#15pin CURVE / SLOW -> OCR      #16pin STOP -> OCR 
				#18pin 60   -> OCR	


camera=picamera.PiCamera()
#camera.start_preview()

while True:	
	#image = cv2.imread("light_r.png")
	camera.capture('capture.jpg',resize=(640,640))		
	image2 =cv2.imread("capture.jpg")
	rows,cols =image2.shape[:2]

	M1=cv2.getRotationMatrix2D((cols/2,rows/2),180,1)
	image=cv2.warpAffine(image2,M1,(cols,rows))
	
	GPIO.output(17,False)
	GPIO.output(18,False)
	GPIO.output(27,False)
	GPIO.output(22,False)
	GPIO.output(23,False)
	GPIO.output(24,False)

	element=cv2.getStructuringElement(cv2.MORPH_CROSS,(3,3))
	hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)   #convert BGR to MSV
       
        speed = image	
#	cv2.imwrite('speed_file.png',speed)

#define color strenght parameters in msv   
 #G 70 100 100/90 255 255    //// 50 80 80/70 255 255 
 #Y 20 100 100/40 255 255
 #R 170 100 100/190 255 255
 #site=www.rapidtables.com ->Web Design ->web color ->RGB 

	rweaker = np.array([175, 90, 80])
	rstronger = np.array([190, 255, 255])
	yweaker = np.array([20, 80, 70])
	ystronger = np.array([40, 255,255])
	gweaker = np.array([50, 80, 80]) #50 0
	gstronger = np.array([70, 255,255]) 
#threshold the MSV image to obtain input color





	check=0;
	#red
	mask = cv2.inRange(hsv,rweaker,rstronger)
	eroded = cv2.erode(mask,element)
	traffic = cv2.dilate(eroded,element)
	intRows,intColumns = traffic.shape
	circles = cv2.HoughCircles(traffic,cv2.HOUGH_GRADIENT,1,100,param1=60,param2=12,minRadius=6,maxRadius=50)

	if circles is not None:
		for circle in circles[0,:]:
			x,y,r=circle
			print "red ball position x= "+str(x)+",y= "+str(y)+",r="+str(r)
			cv2.circle(image,(x,y),r,(255,255,0),1)
			GPIO.output(17,True)
			check=check-1
	else:
		check=check+1
	
	#green
	mask = cv2.inRange(hsv,gweaker,gstronger)
	eroded = cv2.erode(mask,element)
	traffic = cv2.dilate(eroded,element)
	intRows,intColumns = traffic.shape
	circles = cv2.HoughCircles(traffic,cv2.HOUGH_GRADIENT,1,100,param1=60,param2=12,minRadius=8,maxRadius=50)

	if circles is not None:
		for circle in circles[0,:]:
			x,y,r=circle
			print "green ball position x= "+str(x)+",y= "+str(y)+",r="+str(r)
			cv2.circle(image,(x,y),r,(255,255,0),1)
			GPIO.output(18,True)
			check=check-1
	else:
		check=check+1	


	
    	if check==2:
		print "Not Found!"		
#check 0==red 1==green 2==NONE
      	
    	hsv2 = cv2.cvtColor(speed, cv2.COLOR_BGR2HSV)
	mask2 = cv2.inRange(hsv2,yweaker,ystronger)
	
	eroded2 = cv2.erode(mask2,element)
	sign = cv2.dilate(eroded2,element)

        sign = ~sign
	intRows,intColumns = sign.shape	
	cv2.imwrite('speed_ocr_file.png',sign)

#detect color and draw  
#ret,thresh = cv2.threshold(temp,127,255,0)
#_, cnts,_ = cv2.findContours(thresh,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
#c= max(cnts,key=cv2.contourArea)
#peri = cv2.arcLength(c,True)
#approx = cv2.approxPolyDP(c,0.01 * peri,True)
#cv2.drawContours(image,[approx],-1,(0,0,255),2)

#image show
#	cv2.imshow('Image',image)
#	cv2.imshow('Result',traffic)
#	cv2.imshow('speed',speed)
#	cv2.imshow('speed_ocr',speed_ocr)
#	mahotas.imsave('capture_result.jpg',image)
#	cv2.waitKey(0)
#	cv2.destroyAllWindows()
	
#	titles = ['Original Image','Original speed ','traffic','Gaussian speed']
#	images = [image, speed, traffic, sign]
#	for i in xrange(4):
#		cv2.imshow(titles[i],images[i])
#	        cv2.waitKey(0)
#	        cv2.destroyAllWindows()
		
	str2 = pytesseract.image_to_string(Image.open('speed_ocr_file.png'))	

	print str2
	str2="{0:<6}".format(str2)
	str2=str2.strip()
	
	str_check=0
#	
	if str2 in ( "SLOW","SLQW","Qlow","QlOW","SLOw","SLOVV","SLoW","SL0W","SLC)W","BLOW","SL()W") :
		print "okay1"
                GPIO.output(22,True)
                str_check=1
#
	elif str2 in ( "STOP","SToP","ST0P","SlOP","STqP","QTQP","STC)P","ST()P","STc)P" ):
		print "okay2"
                GPIO.output(23,True)
                str_check=2
#
	elif str2 in ( "CURVE","OURVE","CUI3VE","CURUE","(URVE","CURVI"):
		print "okay3"
		GPIO.output(22,True)
		str_check=1
	elif str2 in ("60","6O","6o","6()","6C)","6c)"):
		print "okay4"
		GPIO.output(24, True)
		str_check=3		
	else :
		print "NONE"
		str_check=0

# str_check 0==NONE 1==SLOW/CURVE  2==STOP 3==60
