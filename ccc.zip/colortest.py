import cv2
import numpy as np
import mahotas

image = cv2.imread("light_r.png")

element=cv2.getStructuringElement(cv2.MORPH_CROSS,(3,3))

#convert BGR to MSV
hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

#define color strenght parameters in msv   
 #G 70 100 100/90 255 255    //// 50 80 80/70 255 255 
 #B 110 100 100/130 255 255
 #Y 20 100 100/40 255 255
 #R 170 100 100/190 255 255
 #site=www.rapidtables.com ->Web Design ->web color ->RGB
 
weaker = np.array([50, 80, 80])
stronger = np.array([70, 255,255]) 

#threshold the MSV image to obtain input color
mask = cv2.inRange(hsv, weaker,stronger)

#temp=cv2.dilate(mask,element)
eroded=cv2.erode(mask,element)
temp=cv2.dilate(eroded,element)


mahotas.imsave('eroded_7.png',temp)

cv2.imshow('Image',image)
cv2.imshow('Result',temp)


cv2.waitKey(0)
cv2.destroyAllWindows()
